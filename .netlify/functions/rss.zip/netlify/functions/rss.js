var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/rss.js
var rss_exports = {};
__export(rss_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(rss_exports);
async function handler(event) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json",
    "Cache-Control": "public, max-age=600"
    // 10 min CDN cache
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers };
  }
  const { url, count = "10" } = event.queryStringParameters || {};
  if (!url) {
    return { statusCode: 400, headers, body: JSON.stringify({ status: "error", message: "Missing url" }) };
  }
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; TheBrief/1.0; +https://thebriefnews.org)",
        "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml, */*"
      },
      signal: AbortSignal.timeout(1e4)
    });
    if (!res.ok) {
      return { statusCode: 502, headers, body: JSON.stringify({ status: "error", message: `Feed returned ${res.status}` }) };
    }
    const xml = await res.text();
    const feed = parseFeed(xml, parseInt(count));
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ status: "ok", feed })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ status: "error", message: err.message })
    };
  }
}
function parseFeed(xml, maxCount = 10) {
  const isAtom = xml.includes("<feed") && xml.includes("xmlns");
  const feedTitle = getCdata(xml, "title") || getText(xml, "title") || "";
  const feedImage = getAttr(xml, "image", "url") || getText(getBlock(xml, "image"), "url") || getAttr(xml, "itunes:image", "href") || "";
  const feed = {
    title: cleanText(feedTitle),
    image: feedImage,
    items: []
  };
  const itemTag = isAtom ? "entry" : "item";
  const blocks = splitBlocks(xml, itemTag);
  for (const block of blocks) {
    if (feed.items.length >= maxCount) break;
    const item = parseItem(block, isAtom);
    if (item) feed.items.push(item);
  }
  return feed;
}
function parseItem(block, isAtom) {
  const title = cleanText(getCdata(block, "title") || getText(block, "title") || "");
  if (!title) return null;
  let link = "";
  if (isAtom) {
    link = getAttr(block, `link[^>]*rel=["']alternate["']`, "href") || getAttr(block, "link", "href") || getText(block, "link") || "";
  } else {
    link = getText(block, "link") || getAttr(block, "link", "href") || "";
  }
  const guid = getText(block, isAtom ? "id" : "guid") || link || title;
  const rawDesc = getCdata(block, "description") || getCdata(block, "content:encoded") || getCdata(block, "summary") || getText(block, "description") || getText(block, "summary") || getText(block, "content") || "";
  const description = stripHtml(rawDesc).slice(0, 400);
  const pubDate = getText(block, isAtom ? "updated" : "pubDate") || getText(block, "published") || getText(block, "dc:date") || (/* @__PURE__ */ new Date()).toISOString();
  const author = getCdata(block, "author") || getText(block, "author") || getCdata(block, "dc:creator") || getText(block, "dc:creator") || "";
  let image = getAttr(block, "media:content", "url") || getAttr(block, "media:thumbnail", "url") || getAttr(block, `enclosure[^>]*type=["']image`, "url");
  if (!image) {
    const imgMatch = rawDesc.match(/<img[^>]+src=["']([^"']+)["']/i);
    if (imgMatch) image = imgMatch[1];
  }
  const category = getCdata(block, "category") || getText(block, "category") || "";
  return {
    title,
    link: link.trim(),
    guid: guid.trim(),
    description,
    pubDate,
    author: cleanText(author),
    image: image || null,
    category
  };
}
function splitBlocks(xml, tag) {
  const blocks = [];
  const re = new RegExp(`<${tag}[\\s>]([\\s\\S]*?)<\\/${tag}>`, "gi");
  let m;
  while ((m = re.exec(xml)) !== null) blocks.push(m[1]);
  return blocks;
}
function getBlock(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}[\\s>]([\\s\\S]*?)<\\/${tag}>`, "i"));
  return m ? m[1] : "";
}
function getCdata(xml, tag) {
  const re = new RegExp(`<${tag}[^>]*><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/${tag}>`, "i");
  const m = xml.match(re);
  return m ? m[1].trim() : null;
}
function getText(xml, tag) {
  const re = new RegExp(`<${tag}[^>]*>([^<]*)<\\/${tag}>`, "i");
  const m = xml.match(re);
  return m ? m[1].trim() : null;
}
function getAttr(xml, tag, attr) {
  const re = new RegExp(`<${tag}[^>]*\\s${attr}=["']([^"']+)["']`, "i");
  const m = xml.match(re);
  return m ? m[1] : null;
}
function stripHtml(str) {
  return str.replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&#39;/g, "'").replace(/&apos;/g, "'").replace(/&nbsp;/g, " ").replace(/&#8211;/g, "\u2014").replace(/&#8212;/g, "\u2014").replace(/&#8216;/g, "'").replace(/&#8217;/g, "'").replace(/&#8220;/g, '"').replace(/&#8221;/g, '"').replace(/&#8230;/g, "\u2026").replace(/&#\d+;/g, " ").replace(/&[a-z]+;/g, " ").replace(/\s+/g, " ").trim();
}
function cleanText(str) {
  return stripHtml(str).replace(/\s+/g, " ").trim();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
